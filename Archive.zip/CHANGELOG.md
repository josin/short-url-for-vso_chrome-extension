## 1.2 (2020-01-14)

- Rebranding to Azure DevOps

## 1.1 (2018-04-06)

- Always use HTTPS for vso.io links
- Minor updates to package content

## 1.0

- Initial release
